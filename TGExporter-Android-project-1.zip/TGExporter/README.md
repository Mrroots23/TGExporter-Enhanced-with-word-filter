# TG Exporter (Android)

A WebView wrapper around Telegram Web that injects the "Telegram Group Exporter PRO"
script and saves the result to **Downloads/TGExporter** (TXT / JSON / CSV).

## Get the APK without a PC (GitHub Actions)
1. Create a new GitHub repo and upload the *contents* of this folder (keep `.github/`).
2. Open the **Actions** tab -> **Build APK** -> *Run workflow* (it also runs on every push).
3. When it finishes, open the run and download the **TGExporter-debug-apk** artifact (a zip).
4. Unzip, open `app-debug.apk`, allow "install unknown apps" for your browser/file manager.

## Build with Android Studio
Open this folder, let Gradle sync (Android Studio creates the wrapper), then Build > Build APK(s).
Requires JDK 17 and Android SDK 34.

## Use
1. Open the app and log in to Telegram Web (QR code or phone number).
2. Open the group chat you want to export.
3. Tap **Export** in the top bar; the panel appears. Press **Start**.
4. Keep the app open in the foreground until it finishes. The file is auto-saved to Downloads/TGExporter.

## Changes vs. the original console script
- Native save and copy through a JS bridge (blob downloads don't work in WebView).
- Messages are no longer mixed when you switch chats and re-run.
- "Stop & save" now always saves.
- Date filters use local time; CSV gets a UTF-8 BOM so Excel shows non-Latin text.
- Panel width adapts to narrow screens.

## Known limits
- Depends on Telegram Web's CSS class names; a Telegram UI update may break scraping.
- Web A does not expose message timestamps, so date filters only work on Web K.
- Export only reaches messages older than your current scroll position.
- Only export chats you are a member of, and respect other members' privacy.

package com.tgexporter.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.tgexporter.app.databinding.ActivityMainBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Hosts Telegram Web in a WebView and injects exporter.js (the original console script,
 * lightly patched) when the user taps "Export". Files are saved to Downloads/TGExporter.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var pageReady = false

    private val exporterJs: String by lazy {
        assets.open("exporter.js").bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        // Exporting needs the page alive and visible; keep the screen on while the app is open.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        b.toolbar.inflateMenu(R.menu.main)
        b.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_export -> { injectExporter(); true }
                R.id.action_reload -> { b.webView.reload(); true }
                R.id.action_web_k -> { b.webView.loadUrl(URL_K); true }
                R.id.action_web_a -> { b.webView.loadUrl(URL_A); true }
                R.id.action_clear -> { confirmSignOut(); true }
                else -> false
            }
        }

        with(b.webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true            // Telegram Web stores its session here
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false
            // Telegram may reject WebViews by user agent; drop the "; wv" marker.
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(b.webView, true)
        }

        b.webView.addJavascriptInterface(Bridge(), "AndroidBridge")

        b.webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val scheme = u.scheme ?: return false
                if (scheme == "blob" || scheme == "data" || scheme == "about") return false
                val host = u.host ?: ""
                if (scheme == "https" && (host == "telegram.org" || host.endsWith(".telegram.org"))) return false
                openExternal(u)   // anything else leaves the app, so the JS bridge is never exposed to it
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                pageReady = false
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pageReady = true
            }
        }

        b.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                b.progress.progress = newProgress
                b.progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            // The script uses alert() and confirm(); WebView needs these hooks to show them.
            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton(R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton(R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (b.webView.canGoBack()) b.webView.goBack()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        b.webView.loadUrl(URL_K)
    }

    private fun injectExporter() {
        if (!pageReady) {
            Toast.makeText(this, R.string.not_ready, Toast.LENGTH_SHORT).show()
            return
        }
        b.webView.evaluateJavascript(exporterJs, null)
    }

    private fun confirmSignOut() {
        AlertDialog.Builder(this)
            .setTitle(R.string.clear_title)
            .setMessage(R.string.clear_msg)
            .setPositiveButton(R.string.ok) { _, _ ->
                CookieManager.getInstance().removeAllCookies(null)
                WebStorage.getInstance().deleteAllData()
                b.webView.clearCache(true)
                b.webView.loadUrl(URL_K)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun openExternal(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: ActivityNotFoundException) { }
    }

    override fun onDestroy() {
        (b.webView.parent as? android.view.ViewGroup)?.removeView(b.webView)
        b.webView.destroy()
        super.onDestroy()
    }

    /** Methods here are callable from the page as window.AndroidBridge.* (background thread). */
    inner class Bridge {

        @JavascriptInterface
        fun saveFile(name: String, mime: String, data: String): String = try {
            val fileName = stamped(name)
            val bytes = data.toByteArray(Charsets.UTF_8)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/TGExporter")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("could not create file")
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: throw IllegalStateException("could not open file")
                "OK:Downloads/TGExporter/$fileName"
            } else {
                // Android 7-9: app-specific external storage needs no permission.
                val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
                dir.mkdirs()
                val f = File(dir, fileName)
                f.writeBytes(bytes)
                "OK:${f.absolutePath}"
            }
        } catch (e: Exception) {
            "ERR:" + (e.message ?: e.javaClass.simpleName)
        }

        @JavascriptInterface
        fun copyText(text: String): Boolean {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Telegram export", text))
            }
            return true
        }
    }

    private fun stamped(name: String): String {
        val safe = name.replace(Regex("[^\\w.\\-]"), "_")
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val dot = safe.lastIndexOf('.')
        return if (dot > 0) safe.substring(0, dot) + "_" + ts + safe.substring(dot) else safe + "_" + ts
    }

    companion object {
        private const val URL_K = "https://web.telegram.org/k/"
        private const val URL_A = "https://web.telegram.org/a/"
    }
}

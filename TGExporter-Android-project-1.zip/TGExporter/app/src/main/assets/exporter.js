// ===== Telegram Group Exporter PRO =====
// Paste in the console on web.telegram.org (Web K or Web A) with a GROUP chat open.
// A floating panel appears. Keep the tab visible while it runs.
(() => {
  if (window.__tgx) window.__tgx.destroy();

  const isK = !!document.querySelector(".bubbles-inner");
  const isA = !!document.querySelector(".MessageList");
  if (!isK && !isA) return alert("Open a chat on web.telegram.org first.");

  const box = isK
    ? document.querySelector(".bubbles .scrollable-y") || document.querySelector(".scrollable-y")
    : document.querySelector(".MessageList");
  if (!box) return alert("Couldn't find the chat scroll area.");

  // ---------- state ----------
  const chatKey = location.hash || location.pathname;
  if (window.__tgChatKey !== chatKey) { window.__tgMsgs = new Map(); window.__tgChatKey = chatKey; }
  const msgs = window.__tgMsgs;
  let state = "idle"; // idle | running | paused | done
  let t0 = 0, elapsed = 0, lastTick = 0, idle = 0, startCount = msgs.size;
  let wake = null;
  const SPEEDS = {
    safe:  { timeout: 1500, deb: 250, patience: 40 },
    fast:  { timeout: 900,  deb: 120, patience: 55 },
    turbo: { timeout: 500,  deb: 60,  patience: 80 },
  };

  const dayStart = (v) => (v ? new Date(v + "T00:00:00").getTime() / 1000 : 0);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  // ---- text cleaning ----
  const EMOJI = /[\p{Extended_Pictographic}\p{Emoji_Modifier}\u{1F1E6}-\u{1F1FF}\u{E0020}-\u{E007F}\u20e3\ufe0e\ufe0f]/gu;
  const tidy = (t) =>
    t
      .replace(/[\u200b-\u200f\u202a-\u202e\u2060\ufeff]/g, "")
      .replace(/[ \t\u00a0]+/g, " ")
      .split("\n").map((l) => l.trim()).join("\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  const txt = (el, junk) => {
    if (!el) return "";
    const c = el.cloneNode(true);
    const sel = [junk, "img", "svg", "canvas", "custom-emoji-element", ".emoji", ".custom-emoji"].filter(Boolean).join(",");
    c.querySelectorAll(sel).forEach((n) => n.remove());
    c.querySelectorAll("br").forEach((br) => br.replaceWith("\n"));
    return tidy(c.textContent);
  };
  const oneLine = (s) => tidy(s).replace(/\s+/g, " ");
  const pad = (n) => String(n).padStart(2, "0");
  const fmtDate = (ts) => {
    const d = new Date(ts * 1000);
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  // ---------- scraping ----------
  const grabK = () => {
    box.querySelectorAll(".bubble[data-mid]").forEach((b) => {
      const id = Number(b.dataset.mid);
      if (!id || msgs.has(id) || b.classList.contains("service")) return;
      const g = b.closest(".bubbles-group");
      let sender = oneLine(txt(g && g.querySelector(".name .peer-title, .peer-title")));
      if (!sender) sender = b.classList.contains("is-out") ? "Me" : "Unknown";
      const ts = Number(b.dataset.timestamp) || 0;
      const text = txt(b.querySelector(".message"), ".time, .reactions-container, .reactions, .reply, .web, .name, .peer-title");
      msgs.set(id, { id, ts, when: ts ? fmtDate(ts) : "", sender, text });
    });
  };
  const grabA = () => {
    box.querySelectorAll(".Message[id^='message-']").forEach((m) => {
      const id = Number(m.id.replace("message-", ""));
      if (!id || msgs.has(id)) return;
      let sender = oneLine(txt(m.querySelector(".message-title, .sender-title")));
      if (!sender) sender = m.classList.contains("own") ? "Me" : "Unknown";
      const dg = m.closest(".message-date-group");
      const day = oneLine(txt(dg && dg.querySelector(".sticky-date")));
      const when = (day + " " + oneLine(txt(m.querySelector(".message-time")))).trim();
      const text = txt(m.querySelector(".text-content"), ".MessageMeta, .Reactions, .reply");
      msgs.set(id, { id, ts: 0, when, sender, text });
    });
  };
  const grab = isK ? grabK : grabA;

  // wait for DOM change then a short quiet period (fast, adaptive)
  const waitChange = (timeout, deb) =>
    new Promise((res) => {
      let quiet, done = false;
      const fin = () => { if (done) return; done = true; mo.disconnect(); clearTimeout(quiet); clearTimeout(to); res(); };
      const mo = new MutationObserver(() => { clearTimeout(quiet); quiet = setTimeout(fin, deb); });
      mo.observe(box, { childList: true, subtree: true });
      const to = setTimeout(fin, timeout);
    });

  // ---------- run loop ----------
  const cfg = () => SPEEDS[$("spd").value];
  async function run() {
    if (state === "running") return;
    state = "running";
    lastTick = Date.now();
    if (!t0) t0 = Date.now();
    try { wake = await navigator.wakeLock.request("screen"); } catch (e) {}
    const fromTs = dayStart($("from").value);
    idle = 0;
    setStatus();

    while (state === "running" || state === "paused") {
      if (state === "paused") { await sleep(250); continue; }
      const { timeout, deb, patience } = cfg();
      grab();
      const before = msgs.size;
      box.scrollTop = 0;
      await waitChange(timeout, deb);
      grab();
      if (msgs.size === before) {
        idle++;
        box.scrollTop = 250; await sleep(60); box.scrollTop = 0; // nudge loader
      } else idle = 0;

      const ids = [...msgs.keys()];
      const minId = Math.min(...ids);
      if (isK && $("stopAt").checked && fromTs) {
        const oldest = msgs.get(minId);
        if (oldest && oldest.ts && oldest.ts < fromTs) { finish("Reached your start date"); break; }
      }
      if (minId <= 1 && idle >= 3) { finish("Reached the first message"); break; }
      if (idle >= patience) { finish("Nothing more loads"); break; }
    }
  }
  function finish(msg) {
    if (state === "done") return;
    state = "done";
    if (wake) { try { wake.release(); } catch (e) {} wake = null; }
    setStatus(msg);
    if ($("auto").checked) download();
  }
  function stop() { if (state === "running" || state === "paused") finish("Stopped"); }
  function pauseResume() {
    if (state === "running") { state = "paused"; } else if (state === "paused") { state = "running"; lastTick = Date.now(); }
    else return run();
    setStatus();
  }

  // ---------- export ----------
  const filtered = () => {
    const f = dayStart($("from").value);
    const t = $("to").value ? dayStart($("to").value) + 86399 : 0;
    const who = $("who").value.trim().toLowerCase();
    // keyword filter: comma-separated words, any/all, whole-word, optional exclude
    const kwTerms = $("kw").value.split(",").map((x) => x.trim().toLowerCase()).filter(Boolean);
    const kwAll = $("kwMode").value === "all";
    const kwWhole = $("kwWhole").checked;
    const kwNot = $("kwNot").checked;
    const escRe = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const termRes = kwTerms.map((w) => new RegExp("(?<![\\p{L}\\p{N}_])" + escRe(w) + "(?![\\p{L}\\p{N}_])", "u"));
    const hit = (low, i) => (kwWhole ? termRes[i].test(low) : low.includes(kwTerms[i]));
    const kwOk = (text) => {
      if (!kwTerms.length) return true;
      const low = text.toLowerCase();
      const r = kwAll ? kwTerms.every((_, i) => hit(low, i)) : kwTerms.some((_, i) => hit(low, i));
      return kwNot ? !r : r;
    };
    // message-type filter
    const EMAIL_RE = /[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i;
    const LINK_RE = /https?:\/\/\S+|\bwww\.\S+/i;
    const ftype = $("ftype").value;
    const typeOk = (text) => (ftype === "email" ? EMAIL_RE.test(text) : ftype === "link" ? LINK_RE.test(text) : true);
    const emo = $("emo").checked;
    const cl = (s) => tidy(emo ? s.replace(EMOJI, "") : s);
    return [...msgs.values()]
      .sort((a, b) => a.id - b.id)
      .map((m) => ({ ...m, sender: cl(m.sender).replace(/\s+/g, " ") || "Unknown", text: cl(m.text) }))
      .filter((m) => {
        if (m.ts && f && m.ts < f) return false;
        if (m.ts && t && m.ts > t) return false;
        if (who && !m.sender.toLowerCase().includes(who)) return false;
        if (!kwOk(m.text)) return false;
        if (!typeOk(m.text)) return false;
        if (!$("media").checked && !m.text) return false;
        return true;
      });
  };
  const build = () => {
    const list = filtered();
    const fmt = $("fmt").value;
    const incT = $("inT").checked, incS = $("inS").checked;
    const body = (m) => m.text || "[media/non-text]";
    if (fmt === "json")
      return { data: JSON.stringify(list.map((m) => ({ id: m.id, time: m.when, sender: m.sender, text: body(m) })), null, 2), ext: "json", n: list.length };
    if (fmt === "csv") {
      const q = (s) => '"' + String(s).replace(/"/g, '""') + '"';
      const rows = ["id,time,sender,text", ...list.map((m) => [m.id, q(m.when), q(m.sender), q(body(m))].join(","))];
      return { data: "\ufeff" + rows.join("\n"), ext: "csv", n: list.length };
    }
    const blocks = list.map((m) => {
      const head = [incS ? m.sender : "", incT ? m.when : ""].filter(Boolean).join("  |  ");
      return (head ? head + "\n" : "") + body(m);
    });
    return { data: blocks.join("\n\n\n"), ext: "txt", n: list.length };
  };
  const chatName = () => {
    const el = document.querySelector(".chat-info .peer-title, .ChatInfo .fullName, .MiddleHeader .fullName");
    return (txt(el) || "telegram_group").replace(/[^\w\-]+/g, "_").slice(0, 40);
  };
  function download() {
    const { data, ext, n } = build();
    if (!n) return toast("Nothing to export yet");
    if (window.AndroidBridge) {
      const name = `${chatName()}_history.${ext}`;
      const mime = ext === "json" ? "application/json" : ext === "csv" ? "text/csv" : "text/plain";
      const r = String(AndroidBridge.saveFile(name, mime, data));
      return toast(r.startsWith("OK:") ? `Saved ${n} messages to ${r.slice(3)}` : "Save failed: " + r.slice(4));
    }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([data], { type: "text/plain;charset=utf-8" }));
    a.download = `${chatName()}_history.${ext}`;
    document.body.appendChild(a); a.click(); a.remove();
    toast(`Saved ${n} messages`);
  }
  async function copy() {
    const { data, n } = build();
    try {
      if (window.AndroidBridge) AndroidBridge.copyText(data); else await navigator.clipboard.writeText(data);
      toast(`Copied ${n} messages`);
    } catch (e) { toast("Copy blocked by browser"); }
  }

  // ---------- UI ----------
  const host = document.createElement("div");
  host.style.cssText = "position:fixed;top:12px;right:12px;z-index:2147483647";
  const root = host.attachShadow({ mode: "open" });
  const $ = (id) => root.getElementById(id);
  root.innerHTML = `
  <style>
    *{box-sizing:border-box;font-family:system-ui,-apple-system,Segoe UI,sans-serif}
    .p{width:min(320px,calc(100vw - 24px));background:#15181e;color:#e8ecf3;border:1px solid #2a2f3a;border-radius:14px;box-shadow:0 12px 40px #000a;overflow:hidden;font-size:13px}
    .h{display:flex;align-items:center;gap:8px;padding:10px 12px;background:linear-gradient(135deg,#2a6df4,#7b3ff2);cursor:move;user-select:none}
    .h b{flex:1;font-size:14px}.h span{font-size:11px;background:#0004;padding:2px 8px;border-radius:99px}
    .h button{background:#0003;border:0;color:#fff;width:24px;height:24px;border-radius:6px;cursor:pointer}
    .b{padding:12px;display:flex;flex-direction:column;gap:10px;max-height:75vh;overflow:auto}
    .bar{height:8px;background:#242a36;border-radius:99px;overflow:hidden}
    .bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#2a6df4,#7b3ff2);transition:width .3s}
    .g{display:grid;grid-template-columns:1fr 1fr;gap:8px}
    .c{background:#1d222b;border-radius:10px;padding:8px 10px}.c small{color:#8b95a7;display:block;font-size:11px}.c div{font-size:15px;font-weight:600;margin-top:2px}
    .r{display:flex;gap:8px}
    button.k{flex:1;padding:9px;border:0;border-radius:9px;background:#2a6df4;color:#fff;font-weight:600;cursor:pointer}
    button.k.s{background:#2a303c}button.k.d{background:#d04b4b}button.k:hover{filter:brightness(1.12)}
    select,input[type=date],input[type=text]{width:100%;background:#1d222b;color:#e8ecf3;border:1px solid #2a303c;border-radius:8px;padding:7px;font-size:12px}
    label{display:flex;align-items:center;gap:6px;color:#c4ccda;font-size:12px}
    details{background:#1a1e26;border-radius:10px;padding:8px 10px}summary{cursor:pointer;font-weight:600;color:#aeb8ca}
    details>div{display:flex;flex-direction:column;gap:7px;margin-top:8px}
    .t{font-size:12px;color:#aeb8ca;line-height:1.6}
    .toast{position:absolute;left:12px;right:12px;bottom:12px;background:#2a6df4;color:#fff;padding:8px 10px;border-radius:8px;text-align:center;opacity:0;transition:.25s;pointer-events:none}
    .toast.on{opacity:1}
  </style>
  <div class="p">
    <div class="h" id="hd"><b>TG Exporter PRO</b><span id="st">Idle</span><button id="mn">–</button><button id="xx">✕</button></div>
    <div class="b" id="body">
      <div class="bar"><i id="bar"></i></div>
      <div class="g">
        <div class="c"><small>Messages</small><div id="n">0</div></div>
        <div class="c"><small>Progress (approx)</small><div id="pc">0%</div></div>
        <div class="c"><small>Oldest</small><div id="old" style="font-size:12px">–</div></div>
        <div class="c"><small>Speed / Time</small><div id="sp" style="font-size:13px">–</div></div>
      </div>
      <div class="r"><button class="k" id="go">Start</button><button class="k d" id="sp2">Stop & save</button></div>
      <label>Speed&nbsp;<select id="spd"><option value="safe">Safe</option><option value="fast" selected>Fast</option><option value="turbo">Turbo</option></select></label>
      <details open><summary>Output</summary><div>
        <select id="fmt"><option value="txt">TXT (clean, spaced)</option><option value="json">JSON</option><option value="csv">CSV</option></select>
        <label><input type="checkbox" id="inT" checked>Include time</label>
        <label><input type="checkbox" id="inS" checked>Include sender</label>
        <label><input type="checkbox" id="emo" checked>Remove emoji</label>
        <label><input type="checkbox" id="media">Include media-only messages</label>
        <label><input type="checkbox" id="auto" checked>Auto-download when finished</label>
      </div></details>
      <details><summary>Filters</summary><div>
        <label>From <input type="date" id="from"></label>
        <label>To&nbsp;&nbsp;&nbsp;<input type="date" id="to"></label>
        <label><input type="checkbox" id="stopAt" checked>Stop scrolling at From date (faster)</label>
        <input type="text" id="who" placeholder="Only sender containing…">
        <input type="text" id="kw" placeholder="Words, comma-separated (e.g. approve, approved)">
        <select id="kwMode"><option value="any">Match ANY of the words</option><option value="all">Match ALL of the words</option></select>
        <label><input type="checkbox" id="kwWhole">Whole words only</label>
        <label><input type="checkbox" id="kwNot">Exclude matches instead</label>
        <select id="ftype"><option value="all">Any message</option><option value="email">Only messages with an email address</option><option value="link">Only messages with a link</option></select>
      </div></details>
      <div class="t" id="top">Top senders will appear here</div>
      <div class="r"><button class="k s" id="dl">Download</button><button class="k s" id="cp">Copy</button><button class="k s" id="cl">Clear</button></div>
    </div>
    <div class="toast" id="toast"></div>
  </div>`;
  document.body.appendChild(host);

  function toast(t) {
    const el = $("toast"); el.textContent = t; el.classList.add("on");
    clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove("on"), 3500);
  }
  function setStatus(extra) {
    const s = { idle: "Idle", running: "Running", paused: "Paused", done: extra || "Done" }[state];
    $("st").textContent = s;
    $("go").textContent = state === "running" ? "Pause" : state === "paused" ? "Resume" : state === "done" ? "Run again" : "Start";
  }
  const fmtT = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

  const ui = setInterval(() => {
    if (state === "running") { elapsed += (Date.now() - lastTick) / 1000; lastTick = Date.now(); }
    else lastTick = Date.now();
    const n = msgs.size;
    $("n").textContent = n.toLocaleString();
    if (n) {
      const ids = [...msgs.keys()];
      const minId = Math.min(...ids), maxId = Math.max(...ids);
      const pct = maxId > 1 ? Math.min(100, Math.round(((maxId - minId) / (maxId - 1)) * 100)) : 0;
      $("pc").textContent = pct + "%"; $("bar").style.width = pct + "%";
      const o = msgs.get(minId);
      $("old").textContent = (o.when || "id " + minId).slice(0, 22);
    }
    const rate = elapsed > 1 ? ((n - startCount) / elapsed).toFixed(0) : 0;
    $("sp").textContent = `${rate} msg/s · ${fmtT(elapsed)}`;
    // top senders
    if (n && Math.floor(elapsed) % 2 === 0) {
      const c = {};
      msgs.forEach((m) => (c[m.sender] = (c[m.sender] || 0) + 1));
      const top = Object.entries(c).sort((a, b) => b[1] - a[1]).slice(0, 5);
      $("top").innerHTML = "<b>Top senders</b><br>" + top.map(([k, v]) => `${k.replace(/</g, "&lt;")} — ${v}`).join("<br>");
    }
  }, 500);

  $("go").onclick = () => (state === "idle" || state === "done" ? (state = "idle", run()) : pauseResume());
  $("sp2").onclick = () => { const active = state === "running" || state === "paused"; const auto = $("auto").checked; stop(); if (!(active && auto)) download(); };
  $("dl").onclick = download;
  $("cp").onclick = copy;
  $("cl").onclick = () => { if (confirm("Clear all collected messages?")) { msgs.clear(); startCount = 0; elapsed = 0; toast("Cleared"); } };
  $("xx").onclick = destroy;
  $("mn").onclick = () => { const b = $("body"); b.style.display = b.style.display === "none" ? "flex" : "none"; };

  // drag
  let dx = 0, dy = 0, drag = false;
  $("hd").onpointerdown = (e) => { if (e.target.tagName === "BUTTON") return; drag = true; const r = host.getBoundingClientRect(); dx = e.clientX - r.left; dy = e.clientY - r.top; e.target.setPointerCapture(e.pointerId); };
  $("hd").onpointermove = (e) => { if (!drag) return; host.style.left = e.clientX - dx + "px"; host.style.top = e.clientY - dy + "px"; host.style.right = "auto"; };
  $("hd").onpointerup = () => (drag = false);

  function destroy() { state = "done"; clearInterval(ui); host.remove(); delete window.__tgx; }
  window.__tgx = { destroy, download, stop };
  setStatus();
})();